const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

let users = {};

io.on('connection', (socket) => {
    // Join event
    socket.on('join', (username) => {
        users[socket.id] = username;
        // Broadcast to others only (not self)
        socket.broadcast.emit('chat message', { 
            user: 'System', 
            text: `${username} joined the conversation`, 
            time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) 
        });
    });

    // Chat message event
    socket.on('chat message', (msg) => {
        const username = users[socket.id] || 'Anonymous';
        io.emit('chat message', { 
            user: username, 
            text: msg, 
            time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) 
        });
    });

    // Disconnect event
    socket.on('disconnect', () => {
        if (users[socket.id]) {
            socket.broadcast.emit('chat message', { 
                user: 'System', 
                text: `${users[socket.id]} left the conversation`, 
                time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) 
            });
            delete users[socket.id];
        }
    });
});

server.listen(5000, () => {
    console.log('Server running on http://localhost:5000');
});
